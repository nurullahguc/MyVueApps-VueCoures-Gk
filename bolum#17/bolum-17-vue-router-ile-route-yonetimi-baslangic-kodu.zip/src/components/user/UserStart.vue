<template>
  <div class="container">
    <h3>User Start Component</h3>
    <hr>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium asperiores commodi, dicta doloribus earum
      enim fugiat incidunt nemo, quisquam ratione sapiente sequi ullam, velit vitae voluptatem. A doloremque iste
      veritatis.
    </p>
  </div>
</template>
<script>
  export default {}
</script>
